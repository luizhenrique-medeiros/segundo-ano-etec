package appagenda.controle;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class actLogin extends AppCompatActivity {

    EditText txtNome, txtsenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_login);
        txtNome=findViewById(R.id.txtNome);
        txtsenha=findViewById(R.id.txtsenha);

    }

    public void Login(View view){
        String login=txtNome.getText().toString();
        String senha=txtsenha.getText().toString();
        if(login.equals("manoDown") && senha.equals("jomba") ){
            Intent it = new Intent(this,actCadastro.class);
            it.putExtra( "nome", login);
            it.putExtra( "senha", senha);

            startActivity(it);
        }else{
            Toast.makeText(this, "Login invalido", Toast.LENGTH_SHORT).show();
            txtNome.setText("");
            txtsenha.setText("");
            txtNome.requestFocus();
        }
    }
}