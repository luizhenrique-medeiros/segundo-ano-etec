package appagenda.controle;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import appagenda.cbd.controle.bdAgenda;
public class actCadastro extends AppCompatActivity {



    Button btnCadastrar, btnAlterar, btnConsultar, btnExcluir, btnLimpar;

    EditText edtNome,edtEmail,edtCelular, edtId;

    bdAgenda bdagenda= null;
    SQLiteDatabase bd=null;
    ContentValues valores=null;
    Cursor cursor= null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_act_cadastro);
        edtNome=findViewById(R.id.edtNome);
        edtCelular=findViewById(R.id.edtCelular);
        edtEmail=findViewById(R.id.edtEmail);
        edtId=findViewById(R.id.edtId);
        btnCadastrar=findViewById(R.id.btnCadastrar);
        btnConsultar=findViewById(R.id.btnConsultar);
        btnExcluir=findViewById(R.id.btnExcluir);
        btnAlterar=findViewById(R.id.btnAlterar);
        btnLimpar=findViewById(R.id.btnLimpar);

        bdagenda= new bdAgenda(getBaseContext());
    }
    public void LimparEDT(View view){
        edtEmail.setText("");
        edtNome.setText(null);
        edtCelular.setText(null);
        edtNome.requestFocus();
    }
    public void Cadastrar(View view){
        bd=bdagenda.getWritableDatabase();
        valores= new ContentValues();
        valores.put("nome", edtNome.getText().toString());
        valores.put("email", edtEmail.getText().toString());
        valores.put("Celular", edtCelular.getText().toString());
        valores.put("pass", "");
        bd.insert("contatos",null, valores);
        long linha=bd.insert("contatos", null, valores);
        if(linha<=0){
            Toast.makeText(this, "Erro ao cadastrar", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "Cadastro com sucesso", Toast.LENGTH_SHORT).show();

        }
        LimparEDT(view);
        bd.close();
    }

    public void ConsultarID(View view){
        bd=bdagenda.getReadableDatabase();
        cursor=bd.rawQuery("select * from contatos where id="+ Integer.parseInt(edtId.getText().toString()),null );
        if(cursor.moveToFirst()){
            edtNome.setText(cursor.getString(1));
            edtCelular.setText(cursor.getString(2));
            edtEmail.setText(cursor.getString(3));
        }else{

            Toast.makeText(this, "ID não cadastrado", Toast.LENGTH_SHORT).show();
            LimparEDT(view);
        }
        bd.close();
    }
    public void Alterar(View view){
    bd=bdagenda.getWritableDatabase();
        valores= new ContentValues();
        valores.put("nome", edtNome.getText().toString());
        valores.put("email", edtEmail.getText().toString());
        valores.put("Celular", edtCelular.getText().toString());
        valores.put("pass", "");
        int linha=bd.update("contatos",valores, "id="+Integer.parseInt(edtId.getText().toString()), null);
        if(linha<=0){
            Toast.makeText(this, "Erro ao cadastrar", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "Cadastro com sucesso", Toast.LENGTH_SHORT).show();

        }
        bd.close();
    }

    public void Excluir(View view){
        bd=bdagenda.getWritableDatabase();
        int linha=bd.delete("contatos", "id="+Integer.parseInt(edtId.getText().toString()), null);
        if(linha<=0){
            Toast.makeText(this, "Erro ao cadastrar", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "Cadastro com sucesso", Toast.LENGTH_SHORT).show();

        }
        bd.close();


    }
    public void Sair(View view) {
        this.finish();
    }

}